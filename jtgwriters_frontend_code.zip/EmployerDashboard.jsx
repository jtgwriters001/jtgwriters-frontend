// src/pages/EmployerDashboard.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function EmployerDashboard() {
  const [employer, setEmployer] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [amount, setAmount] = useState(0);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [topic, setTopic] = useState("");
  const [format, setFormat] = useState("");
  const [instructions, setInstructions] = useState("");
  const [biddingDeadline, setBiddingDeadline] = useState("");
  const [file, setFile] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        const res = await axios.get('/api/employer/me');
        setEmployer(res.data);
        const taskRes = await axios.get('/api/employer/tasks');
        setTasks(taskRes.data);
      } catch (err) {
        console.error(err);
      }
    }
    loadData();
  }, []);

  const handleTopUp = async () => {
    try {
      await axios.post('/api/employer/topup', { amount });
      alert('STK Push sent! Complete payment on your phone.');
    } catch (err) {
      console.error('Top-up failed:', err);
    }
  };

  const handleTaskPost = async () => {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('topic', topic);
    formData.append('format', format);
    formData.append('amount', amount);
    formData.append('instructions', instructions);
    formData.append('bidding_deadline', biddingDeadline);
    formData.append('file', file);
    try {
      await axios.post('/api/employer/create_task', formData);
      alert('Task created!');
    } catch (err) {
      alert('Error posting task.');
    }
  };

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-xl font-bold">Employer Dashboard</h1>
      {employer && (
        <div className="bg-white rounded-xl p-4 shadow">
          <p><strong>Email:</strong> {employer.email}</p>
          <p><strong>Balance:</strong> KES {employer.balance}</p>
        </div>
      )}

      <div className="flex space-x-2">
        <input
          type="number"
          placeholder="Amount (KES)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="border p-2 rounded"
        />
        <Button onClick={handleTopUp}>Top Up</Button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow space-y-2">
        <h2 className="text-lg font-semibold">Post New Task</h2>
        <input className="border w-full p-2 rounded" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea className="border w-full p-2 rounded" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <input className="border w-full p-2 rounded" placeholder="Topic" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <input className="border w-full p-2 rounded" placeholder="Format (APA, MLA, etc.)" value={format} onChange={(e) => setFormat(e.target.value)} />
        <textarea className="border w-full p-2 rounded" placeholder="Instructions for writer" value={instructions} onChange={(e) => setInstructions(e.target.value)} />
        <input className="border w-full p-2 rounded" type="datetime-local" value={biddingDeadline} onChange={(e) => setBiddingDeadline(e.target.value)} />
        <input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files[0])} />
        <Button onClick={handleTaskPost}>Submit Task</Button>
      </div>

      <h2 className="text-lg font-semibold">Posted Tasks</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {tasks.map(task => (
          <Card key={task.id}>
            <CardContent>
              <p><strong>Title:</strong> {task.title}</p>
              <p><strong>Status:</strong> {task.status}</p>
              <p><strong>Amount:</strong> KES {task.amount}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
