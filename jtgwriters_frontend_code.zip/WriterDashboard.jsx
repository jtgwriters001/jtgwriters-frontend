// src/pages/WriterDashboard.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function WriterDashboard() {
  const [writer, setWriter] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [file, setFile] = useState(null);
  const [uploadMessage, setUploadMessage] = useState("");

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await axios.get('/api/writer/me');
        setWriter(res.data);
        const taskRes = await axios.get('/api/writer/tasks');
        setTasks(taskRes.data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchData();
  }, []);

  const handleFileUpload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await axios.post('/api/writer/upload_sample', formData);
      setUploadMessage("File uploaded successfully.");
    } catch (err) {
      setUploadMessage("Upload failed.");
    }
  };

  const handleBid = async (taskId) => {
    try {
      await axios.post(`/api/writer/bid/${taskId}`);
      alert('Bid placed successfully!');
    } catch (err) {
      alert('Failed to place bid.');
    }
  };

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-xl font-bold">Welcome, Writer</h1>
      {writer && (
        <div className="bg-white rounded-xl p-4 shadow">
          <p><strong>Phone:</strong> {writer.phone}</p>
          <p><strong>Status:</strong> {writer.is_active ? 'Active' : 'Inactive'}</p>
          <p><strong>Verified:</strong> {writer.is_verified ? 'Yes' : 'Pending Review'}</p>
          <p><strong>Failed Attempts:</strong> {writer.failed_attempts}</p>
        </div>
      )}

      <h2 className="text-lg font-semibold">Submit Sample</h2>
      <input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files[0])} />
      <Button onClick={handleFileUpload}>Upload</Button>
      {uploadMessage && <p>{uploadMessage}</p>}

      <h2 className="text-lg font-semibold">Available Tasks</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {tasks.length === 0 ? <p>No tasks yet.</p> : tasks.map(task => (
          <Card key={task.id}>
            <CardContent>
              <p><strong>Title:</strong> {task.title}</p>
              <p><strong>Topic:</strong> {task.topic}</p>
              <p><strong>Format:</strong> {task.format}</p>
              <p><strong>Status:</strong> {task.status}</p>
              <p><strong>Amount:</strong> KES {task.amount}</p>
              <p><strong>Instructions:</strong> {task.instructions}</p>
              <p><strong>Bidding Deadline:</strong> {task.bidding_deadline}</p>
              <Button onClick={() => handleBid(task.id)}>Bid for Task</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
